import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../viewmodels/trip_vm.dart';
import '../../models/trip_model.dart';

class CreateTripPage extends StatefulWidget {
  const CreateTripPage({super.key});

  @override
  State<CreateTripPage> createState() => _CreateTripPageState();
}

class _CreateTripPageState extends State<CreateTripPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController originC = TextEditingController();
  final TextEditingController destinationC = TextEditingController();
  final TextEditingController quotaC = TextEditingController();
  final TextEditingController priceC = TextEditingController();
  final TextEditingController notesC = TextEditingController();

  DateTime? selectedDate;

  Future<void> pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: now,
      lastDate: DateTime(now.year + 5),
    );

    if (picked != null) {
      setState(() => selectedDate = picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Buat Trip Baru")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: originC,
                decoration: const InputDecoration(labelText: "Asal"),
                validator: (v) => v!.isEmpty ? "Tidak boleh kosong" : null,
              ),
              TextFormField(
                controller: destinationC,
                decoration: const InputDecoration(labelText: "Tujuan"),
                validator: (v) => v!.isEmpty ? "Tidak boleh kosong" : null,
              ),

              const SizedBox(height: 12),

              // Tanggal keberangkatan
              GestureDetector(
                onTap: pickDate,
                child: AbsorbPointer(
                  child: TextFormField(
                    decoration: InputDecoration(
                      labelText: "Tanggal Berangkat",
                      hintText: selectedDate == null
                          ? "Pilih tanggal"
                          : "${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year}",
                    ),
                    validator: (_) =>
                        selectedDate == null ? "Tanggal belum dipilih" : null,
                  ),
                ),
              ),

              TextFormField(
                controller: quotaC,
                decoration: const InputDecoration(labelText: "Kapasitas"),
                keyboardType: TextInputType.number,
                validator: (v) => v!.isEmpty ? "Tidak boleh kosong" : null,
              ),

              TextFormField(
                controller: priceC,
                decoration: const InputDecoration(labelText: "Harga Jasa"),
                keyboardType: TextInputType.number,
                validator: (v) => v!.isEmpty ? "Tidak boleh kosong" : null,
              ),

              TextFormField(
                controller: notesC,
                decoration: const InputDecoration(labelText: "Catatan (opsional)"),
                maxLines: 3,
              ),

              const SizedBox(height: 20),

              Consumer<TripViewModel>(
                builder: (context, vm, _) {
                  return ElevatedButton(
                    onPressed: vm.isLoading
                        ? null
                        : () async {
                            if (_formKey.currentState!.validate()) {
                              final trip = TripModel(
                                id: "", // auto-generate in service
                                jastiperId:
                                    "dummyUserId", // TODO: ganti FirebaseAuth.currentUser!.uid
                                origin: originC.text,
                                destination: destinationC.text,
                                departureDate: selectedDate!,
                                quota: int.tryParse(quotaC.text) ?? 0,
                                price: double.tryParse(priceC.text) ?? 0,
                                notes: notesC.text,
                                isOpen: true,
                                createdAt: DateTime.now(),
                              );

                              final success = await vm.createTrip(trip);

                              if (!context.mounted) return;

                              if (success) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                      content: Text("Trip berhasil dibuat!")),
                                );
                                Navigator.pop(context);
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                      content: Text("Gagal membuat trip")),
                                );
                              }
                            }
                          },
                    child: vm.isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text("Simpan Trip"),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
