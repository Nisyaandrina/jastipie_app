import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

import '../../models/trip_model.dart';
import '../../viewmodels/trip_vm.dart';

class TripDetailPage extends StatelessWidget {
  final String tripId;

  const TripDetailPage({super.key, required this.tripId});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      // gunakan method yang ada di TripViewModel: fetchTripDetail
      create: (_) => TripViewModel()..fetchTripDetail(tripId),
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Detail Trip"),
        ),
        body: Consumer<TripViewModel>(
          builder: (context, vm, _) {
            if (vm.isLoading) {
              return const Center(child: CircularProgressIndicator());
            }

            final TripModel? trip = vm.tripDetail; // sesuai TripViewModel sebelumnya

            if (trip == null) {
              return const Center(
                child: Text("Trip tidak ditemukan."),
              );
            }

            // Format tanggal & harga
            final dateStr = DateFormat('dd MMM yyyy').format(trip.departureDate);
            final priceStr = NumberFormat.currency(
              locale: 'id_ID',
              symbol: 'Rp ',
              decimalDigits: 0,
            ).format(trip.price);

            return Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildItem("Asal", trip.origin),
                  _buildItem("Tujuan", trip.destination),
                  _buildItem("Tanggal", dateStr),
                  _buildItem("Kapasitas", trip.quota.toString()),
                  _buildItem("Harga", priceStr),
                  if (trip.notes.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    _buildItem("Catatan", trip.notes),
                  ],
                  const SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("Fitur Accept Booking belum diintegrasikan."),
                        ),
                      );
                    },
                    child: const Text("Accept Booking"),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 16)),
        ],
      ),
    );
  }
}
