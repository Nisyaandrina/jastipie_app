class AppConstants {
  static const String appName = "JASTIPIE";
  static const String apiBaseUrl = "https://api.jastipie.com";
  static const int defaultTimeout = 30; // detik
}