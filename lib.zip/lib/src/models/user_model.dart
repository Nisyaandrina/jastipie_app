class UserModel {
  final String id;
  final String email;
  final String? name;
  final String? phone;
  final String? photoUrl;
  final String role;
  final String? createdAt;   // String ISO, bukan Timestamp
  final String? updatedAt;

  UserModel({
    required this.id,
    required this.email,
    this.name,
    this.phone,
    this.photoUrl,
    this.role = "customer",
    this.createdAt,
    this.updatedAt,
  });

  /// Convert Firestore map → UserModel
  factory UserModel.fromMap(String id, Map<String, dynamic> map) {
    return UserModel(
      id: id,
      email: map['email'] ?? '',
      name: map['name'],
      phone: map['phone'],
      photoUrl: map['photoUrl'],
      role: map['role'] ?? "customer",
      createdAt: map['createdAt'],   // langsung ambil string
      updatedAt: map['updatedAt'],
    );
  }

  /// Convert UserModel → Map untuk Firestore
  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'name': name ?? "",
      'phone': phone ?? "",
      'photoUrl': photoUrl ?? "",
      'role': role,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
    };
  }

  /// copyWith untuk update sebagian
  UserModel copyWith({
    String? name,
    String? phone,
    String? photoUrl,
    String? role,
    String? updatedAt,
  }) {
    return UserModel(
      id: id,
      email: email,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      photoUrl: photoUrl ?? this.photoUrl,
      role: role ?? this.role,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
